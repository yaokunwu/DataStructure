// Ozbirn, 08/21/19
// Simple Java program, prints Hello World and displays 2 command line arguments.
// Run as "java HelloWorld arg1 arg2" where arg1 and arg2 are any strings.

public class HelloWorld
{
   public static void main(String args[])
   {
      System.out.println("Hello World!");  
      System.out.println(args[0]); 
      System.out.println(args[1]); 
   }
}