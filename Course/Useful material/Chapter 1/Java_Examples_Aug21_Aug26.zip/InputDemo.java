// Ozbirn, 08/21/19
// Demonstrates reading a name and printing it.

import java.util.Scanner;

public class InputDemo
{
   public static void main(String args[])
   {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter your name: ");
      
      String name = sc.nextLine();
      System.out.println("Hello " + name);
   }
}