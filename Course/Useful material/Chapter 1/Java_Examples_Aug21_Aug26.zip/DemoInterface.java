// Ozbirn, 08/26/19
// Demonstrates interfaces and inheritance.

interface Payable
{
   void makePayment();
}

class Account implements Payable
{
   public void makePayment()
   {
      System.out.println("Paid the account");
   }
}

class Employee implements Payable
{
   public void makePayment()
   {
      System.out.println("Paid the employee");
   }
}

class HourlyEmployee extends Employee
{
   public void makePayment()
   {
      System.out.println("Paid the hourly employee");
   }
}

public class DemoInterface
{
   public static void main(String args[])
   {
      Account acct1 = new Account();
      Employee emp1 = new Employee();
      HourlyEmployee hremp1 = new HourlyEmployee();
      
      Payable arr[] = new Payable[3];
      arr[0] = acct1;
      arr[1] = emp1;
      arr[2] = hremp1;
      
      for (Payable p : arr)
         p.makePayment();
      
      Employee arr2[] = new Employee[2];
      arr2[0] = emp1;
      arr2[1] = hremp1;
      
      for (Employee e : arr2)
         e.makePayment();
   }
}