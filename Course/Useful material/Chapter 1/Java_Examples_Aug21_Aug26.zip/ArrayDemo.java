// Ozbirn, 08/21/19
// Demonstrates using an array.

public class ArrayDemo
{
   public static void main(String args[])
   {
      int arr[] = new int[5];
      
      arr[0] = 5;
      arr[1] = 10;
      arr[2] = 15;
      arr[3] = 20;
      arr[4] = 25;
      
      // sum with for-loop
      int sum = 0;
      for (int i=0; i<5; i++)
         sum += arr[i];
      System.out.println("Sum is: " + sum);

      // sum with for-each loop
      sum = 0;
      for (int i : arr)
        sum += i;
      System.out.println("Sum is: " + sum);
   }
}