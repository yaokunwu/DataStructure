// Ozbirn, 08/26/19
// Demonstrates Comparable interface.

class Employee implements Comparable<Employee>
{
   private String name;
   private int age;
   
   Employee(String n, int a)
   {
      name = n;
      age = a;
   }
   
   public int getAge()
   {
      return age;
   }
   
   public String getName()
   {
      return name;
   }
   
   public int compareTo(Employee o)
   {
      if (age > o.getAge())
         return 1;
      else if (age < o.getAge())
         return -1;
      else
         return 0;
   }      
   
   public String toString()
   {
      return name;
   }   
}

public class DemoComparable
{
   public static Employee findOldest(Employee arr[])
   {
      // assume arr is not empty...
      Employee oldest = arr[0];
      for (Employee e : arr)
         if (e.compareTo(oldest) > 0)
            oldest = e; 
      return oldest;     
   }

   public static void main(String args[])
   {
      Employee arr[] = { new Employee("Joe", 32),
                         new Employee("Sue", 37),
                         new Employee("Bob", 28) };
                         
      Employee oldest = findOldest(arr);
      System.out.println("Oldest is: " + oldest.getName());
      System.out.println("Oldest is: " + oldest); // use toString()
   }
}